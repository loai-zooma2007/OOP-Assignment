set(__QT_DEPLOY_TARGETS "ImageProcessing_APP_v001")
set(__QT_DEPLOY_TARGET_ImageProcessing_APP_v001_FILE C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/ImageProcessing_APP_v001.exe)
set(__QT_DEPLOY_TARGET_ImageProcessing_APP_v001_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_ImageProcessing_APP_v001_RUNTIME_DLLS C:/Qt/6.12.0/mingw_64/bin/Qt6Widgets.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6Gui.dll;C:/Qt/6.12.0/mingw_64/bin/Qt6Core.dll)
