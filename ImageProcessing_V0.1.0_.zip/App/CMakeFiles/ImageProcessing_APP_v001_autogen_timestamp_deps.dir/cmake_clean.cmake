
# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ImageProcessing_APP_v001_autogen_timestamp_deps.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
