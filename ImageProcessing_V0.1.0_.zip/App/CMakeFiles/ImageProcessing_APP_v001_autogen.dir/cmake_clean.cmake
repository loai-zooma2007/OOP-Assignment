file(REMOVE_RECURSE
  "CMakeFiles/ImageProcessing_APP_v001_autogen"
  "ImageProcessing_APP_v001_autogen/include/ui_mainwindow.h"
  "ImageProcessing_APP_v001_autogen/mocs_compilation.cpp"
  "ImageProcessing_APP_v001_autogen/timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ImageProcessing_APP_v001_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
