
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "" "ImageProcessing_APP_v001_autogen/timestamp" "custom" "ImageProcessing_APP_v001_autogen/deps"
  "C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/Filter.cpp" "CMakeFiles/ImageProcessing_APP_v001.dir/Filter.cpp.obj" "gcc" "CMakeFiles/ImageProcessing_APP_v001.dir/Filter.cpp.obj.d"
  "C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/ImageProcessing_APP_v001_autogen/mocs_compilation.cpp" "CMakeFiles/ImageProcessing_APP_v001.dir/ImageProcessing_APP_v001_autogen/mocs_compilation.cpp.obj" "gcc" "CMakeFiles/ImageProcessing_APP_v001.dir/ImageProcessing_APP_v001_autogen/mocs_compilation.cpp.obj.d"
  "C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/main.cpp" "CMakeFiles/ImageProcessing_APP_v001.dir/main.cpp.obj" "gcc" "CMakeFiles/ImageProcessing_APP_v001.dir/main.cpp.obj.d"
  "C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/mainwindow.cpp" "CMakeFiles/ImageProcessing_APP_v001.dir/mainwindow.cpp.obj" "gcc" "CMakeFiles/ImageProcessing_APP_v001.dir/mainwindow.cpp.obj.d"
  "C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/stb_implementation.cpp" "CMakeFiles/ImageProcessing_APP_v001.dir/stb_implementation.cpp.obj" "gcc" "CMakeFiles/ImageProcessing_APP_v001.dir/stb_implementation.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
