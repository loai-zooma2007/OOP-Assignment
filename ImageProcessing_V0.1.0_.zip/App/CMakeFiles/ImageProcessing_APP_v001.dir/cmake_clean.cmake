file(REMOVE_RECURSE
  "CMakeFiles/ImageProcessing_APP_v001_autogen.dir/AutogenUsed.txt"
  "CMakeFiles/ImageProcessing_APP_v001_autogen.dir/ParseCache.txt"
  "ImageProcessing_APP_v001_autogen"
  "CMakeFiles/ImageProcessing_APP_v001.dir/Filter.cpp.obj"
  "CMakeFiles/ImageProcessing_APP_v001.dir/Filter.cpp.obj.d"
  "CMakeFiles/ImageProcessing_APP_v001.dir/ImageProcessing_APP_v001_autogen/mocs_compilation.cpp.obj"
  "CMakeFiles/ImageProcessing_APP_v001.dir/ImageProcessing_APP_v001_autogen/mocs_compilation.cpp.obj.d"
  "CMakeFiles/ImageProcessing_APP_v001.dir/main.cpp.obj"
  "CMakeFiles/ImageProcessing_APP_v001.dir/main.cpp.obj.d"
  "CMakeFiles/ImageProcessing_APP_v001.dir/mainwindow.cpp.obj"
  "CMakeFiles/ImageProcessing_APP_v001.dir/mainwindow.cpp.obj.d"
  "CMakeFiles/ImageProcessing_APP_v001.dir/stb_implementation.cpp.obj"
  "CMakeFiles/ImageProcessing_APP_v001.dir/stb_implementation.cpp.obj.d"
  "ImageProcessing_APP_v001.exe"
  "ImageProcessing_APP_v001.exe.manifest"
  "ImageProcessing_APP_v001.pdb"
  "ImageProcessing_APP_v001_autogen/mocs_compilation.cpp"
  "ImageProcessing_APP_v001_autogen/timestamp"
  "libImageProcessing_APP_v001.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ImageProcessing_APP_v001.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
