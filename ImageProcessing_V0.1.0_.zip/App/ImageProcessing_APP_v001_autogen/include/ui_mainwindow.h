/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QStackedWidget *stackedWidget;
    QWidget *HomePage;
    QVBoxLayout *verticalLayout;
    QLabel *APPname;
    QLabel *Wellcoe;
    QPushButton *Edit;
    QPushButton *Exit;
    QLabel *descriptional;
    QWidget *EditPage;
    QGridLayout *gridLayout_2;
    QPushButton *Back_2;
    QPushButton *Save;
    QLabel *imageLabel;
    QPushButton *apply;
    QPushButton *open;
    QLabel *Title;
    QPushButton *reset;
    QLabel *ImageDetails;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1026, 532);
        MainWindow->setStyleSheet(QString::fromUtf8("QMainWindow{background-color: rgb(0, 85, 255);}\n"
"\n"
"\n"
"\n"
"\n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName("gridLayout");
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setStyleSheet(QString::fromUtf8("QStackedWidget{background-color: rgb(194, 194, 194);}\n"
"QLabel{color: rgb(255, 255, 255);}\n"
"\n"
""));
        HomePage = new QWidget();
        HomePage->setObjectName("HomePage");
        HomePage->setStyleSheet(QString::fromUtf8("QWidget{background-color: rgb(16, 24, 39);}\n"
"QPushButton{background-color: rgb(36, 120, 243);color: rgb(255, 255, 255);\n"
"border:none;\n"
"border-radius:8px;\n"
"padding:10px 24px;\n"
"font-weight: blod;\n"
"}\n"
"QPushButton:hover{background-color: rgb(71, 149, 255);}"));
        verticalLayout = new QVBoxLayout(HomePage);
        verticalLayout->setObjectName("verticalLayout");
        APPname = new QLabel(HomePage);
        APPname->setObjectName("APPname");
        APPname->setMinimumSize(QSize(0, 0));
        APPname->setMaximumSize(QSize(1000, 1000));
        QFont font;
        font.setFamilies({QString::fromUtf8("Berlin Sans FB Demi")});
        font.setPointSize(50);
        font.setBold(true);
        font.setItalic(false);
        font.setUnderline(false);
        font.setStrikeOut(false);
        font.setKerning(true);
        font.setStyleStrategy(QFont::PreferDefault);
        font.setHintingPreference(QFont::PreferFullHinting);
        APPname->setFont(font);
        APPname->setFrameShape(QFrame::Shape::NoFrame);
        APPname->setFrameShadow(QFrame::Shadow::Plain);
        APPname->setMidLineWidth(0);
        APPname->setAlignment(Qt::AlignmentFlag::AlignCenter);
        APPname->setWordWrap(false);
        APPname->setMargin(0);
        APPname->setIndent(100);

        verticalLayout->addWidget(APPname, 0, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignVCenter);

        Wellcoe = new QLabel(HomePage);
        Wellcoe->setObjectName("Wellcoe");
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Sitka Display Semibold")});
        font1.setPointSize(15);
        Wellcoe->setFont(font1);
        Wellcoe->setAlignment(Qt::AlignmentFlag::AlignCenter);

        verticalLayout->addWidget(Wellcoe, 0, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignTop);

        Edit = new QPushButton(HomePage);
        Edit->setObjectName("Edit");
        Edit->setMinimumSize(QSize(200, 0));
        Edit->setMaximumSize(QSize(350, 45));
        QFont font2;
        font2.setPointSize(11);
        Edit->setFont(font2);
        Edit->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        Edit->setLayoutDirection(Qt::LayoutDirection::RightToLeft);
        QIcon icon(QIcon::fromTheme(QIcon::ThemeIcon::MailMessageNew));
        Edit->setIcon(icon);

        verticalLayout->addWidget(Edit, 0, Qt::AlignmentFlag::AlignHCenter);

        Exit = new QPushButton(HomePage);
        Exit->setObjectName("Exit");
        Exit->setMinimumSize(QSize(200, 0));
        Exit->setMaximumSize(QSize(350, 40));
        QFont font3;
        font3.setPointSize(12);
        Exit->setFont(font3);
        Exit->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        Exit->setLayoutDirection(Qt::LayoutDirection::RightToLeft);
        Exit->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(121, 121, 121);border:none;\n"
"border-radius:8px;\n"
"padding:10px 24px;\n"
"font-weight: blod;}\n"
"QPushButton:hover{background-color: rgb(245, 0, 0);}\n"
"\n"
"\n"
""));
        QIcon icon1(QIcon::fromTheme(QIcon::ThemeIcon::ApplicationExit));
        Exit->setIcon(icon1);
        Exit->setIconSize(QSize(15, 15));

        verticalLayout->addWidget(Exit, 0, Qt::AlignmentFlag::AlignHCenter);

        descriptional = new QLabel(HomePage);
        descriptional->setObjectName("descriptional");
        QFont font4;
        font4.setPointSize(10);
        descriptional->setFont(font4);
        descriptional->setAlignment(Qt::AlignmentFlag::AlignCenter);

        verticalLayout->addWidget(descriptional, 0, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignVCenter);

        stackedWidget->addWidget(HomePage);
        EditPage = new QWidget();
        EditPage->setObjectName("EditPage");
        EditPage->setStyleSheet(QString::fromUtf8("QLabel{color: rgb(0, 85, 255);}\n"
"QPushButton{background-color: rgb(36, 120, 243);color: rgb(255, 255, 255);\n"
"border:none;\n"
"border-radius:8px;\n"
"padding:10px 24px;\n"
"font-weight: blod;\n"
"}\n"
"QPushButton:hover{background-color: rgb(71, 149, 255);}"));
        gridLayout_2 = new QGridLayout(EditPage);
        gridLayout_2->setObjectName("gridLayout_2");
        Back_2 = new QPushButton(EditPage);
        Back_2->setObjectName("Back_2");
        Back_2->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        QIcon icon2(QIcon::fromTheme(QIcon::ThemeIcon::GoPrevious));
        Back_2->setIcon(icon2);

        gridLayout_2->addWidget(Back_2, 0, 0, 1, 1, Qt::AlignmentFlag::AlignLeft);

        Save = new QPushButton(EditPage);
        Save->setObjectName("Save");
        QFont font5;
        font5.setPointSize(8);
        Save->setFont(font5);
        Save->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        QIcon icon3(QIcon::fromTheme(QIcon::ThemeIcon::DocumentSave));
        Save->setIcon(icon3);

        gridLayout_2->addWidget(Save, 2, 0, 1, 1);

        imageLabel = new QLabel(EditPage);
        imageLabel->setObjectName("imageLabel");
        imageLabel->setAlignment(Qt::AlignmentFlag::AlignCenter);

        gridLayout_2->addWidget(imageLabel, 1, 0, 1, 10);

        apply = new QPushButton(EditPage);
        apply->setObjectName("apply");
        apply->setFont(font5);
        apply->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        QIcon icon4(QIcon::fromTheme(QIcon::ThemeIcon::DocumentProperties));
        apply->setIcon(icon4);

        gridLayout_2->addWidget(apply, 2, 1, 1, 1);

        open = new QPushButton(EditPage);
        open->setObjectName("open");
        open->setFont(font5);
        open->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        QIcon icon5(QIcon::fromTheme(QIcon::ThemeIcon::DocumentNew));
        open->setIcon(icon5);

        gridLayout_2->addWidget(open, 2, 2, 1, 1);

        Title = new QLabel(EditPage);
        Title->setObjectName("Title");
        QFont font6;
        font6.setPointSize(15);
        Title->setFont(font6);
        Title->setCursor(QCursor(Qt::CursorShape::ArrowCursor));

        gridLayout_2->addWidget(Title, 0, 4, 1, 1);

        reset = new QPushButton(EditPage);
        reset->setObjectName("reset");
        reset->setMinimumSize(QSize(50, 0));
        reset->setMaximumSize(QSize(100, 16777215));
        reset->setCursor(QCursor(Qt::CursorShape::PointingHandCursor));
        QIcon icon6(QIcon::fromTheme(QIcon::ThemeIcon::SystemReboot));
        reset->setIcon(icon6);

        gridLayout_2->addWidget(reset, 2, 9, 1, 1);

        ImageDetails = new QLabel(EditPage);
        ImageDetails->setObjectName("ImageDetails");
        ImageDetails->setWordWrap(true);

        gridLayout_2->addWidget(ImageDetails, 2, 5, 1, 4);

        stackedWidget->addWidget(EditPage);

        gridLayout->addWidget(stackedWidget, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        APPname->setText(QCoreApplication::translate("MainWindow", "PIXEL LAB", nullptr));
        Wellcoe->setText(QCoreApplication::translate("MainWindow", "Wellcome to PIXEL LAB", nullptr));
        Edit->setText(QCoreApplication::translate("MainWindow", "Edit Image ", nullptr));
        Exit->setText(QCoreApplication::translate("MainWindow", "Exit ", nullptr));
        descriptional->setText(QCoreApplication::translate("MainWindow", "Transform your images . Explore your creativity.", nullptr));
        Back_2->setText(QString());
        Save->setText(QCoreApplication::translate("MainWindow", "Save ", nullptr));
        imageLabel->setText(QString());
        apply->setText(QCoreApplication::translate("MainWindow", "Edit", nullptr));
        open->setText(QCoreApplication::translate("MainWindow", "Load", nullptr));
        Title->setText(QCoreApplication::translate("MainWindow", "Editor Studio", nullptr));
        reset->setText(QString());
        ImageDetails->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
