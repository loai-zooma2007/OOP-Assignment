# This file is managed by Qt Creator, do not edit!

set("CMAKE_BUILD_TYPE" "Release" CACHE "STRING" "" FORCE)
set("CMAKE_COLOR_DIAGNOSTICS" "ON" CACHE "BOOL" "" FORCE)
set("CMAKE_CXX_COMPILER" "C:/Qt/Tools/mingw1310_64/bin/g++.exe" CACHE "FILEPATH" "" FORCE)
set("CMAKE_C_COMPILER" "C:/Qt/Tools/mingw1310_64/bin/gcc.exe" CACHE "FILEPATH" "" FORCE)
set("CMAKE_GENERATOR" "MinGW Makefiles" CACHE "STRING" "" FORCE)
set("CMAKE_PREFIX_PATH" "C:/Qt/6.12.0/mingw_64" CACHE "PATH" "" FORCE)
set("CMAKE_PROJECT_INCLUDE_BEFORE" "C:/Users/3m/OneDrive/Documents/ImageProcessing_APP_v001/build/Desktop_Qt_6_12_0_MinGW_64_bit_Release/.qtcreator/cmake-helper/qtcreator-project.cmake" CACHE "FILEPATH" "" FORCE)
set("QT_CREATOR_ENABLE_MAINTENANCE_TOOL_PROVIDER" "ON" CACHE "BOOL" "" FORCE)
set("QT_CREATOR_ENABLE_PACKAGE_MANAGER_SETUP" "ON" CACHE "BOOL" "" FORCE)
set("QT_ENABLE_QML_DEBUG" "OFF" CACHE "BOOL" "" FORCE)
set("QT_QMAKE_EXECUTABLE" "C:/Qt/6.12.0/mingw_64/bin/qmake.exe" CACHE "FILEPATH" "" FORCE)